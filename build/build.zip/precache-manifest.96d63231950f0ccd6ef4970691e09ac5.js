self.__precacheManifest = [
  {
    "revision": "ae25c318b5675506225e",
    "url": "/work/currencio/static/css/main.7bed04cd.chunk.css"
  },
  {
    "revision": "ae25c318b5675506225e",
    "url": "/work/currencio/static/js/main.854f5bb2.chunk.js"
  },
  {
    "revision": "18f607e059774a0f23e2",
    "url": "/work/currencio/static/js/runtime~main.06347253.js"
  },
  {
    "revision": "999c10d60ad850a1a8ca",
    "url": "/work/currencio/static/js/2.15442a32.chunk.js"
  },
  {
    "revision": "3c31d2a60ee18817aa783d319e31f1a0",
    "url": "/work/currencio/static/media/background-min.3c31d2a6.png"
  },
  {
    "revision": "7fc562a33ad0a143c1d3b7d0bd00e096",
    "url": "/work/currencio/index.html"
  }
];